package com.CRM.persistence;

import com.CRM.domain.CRM_userVO;
import com.CRM.dto.LoginDTO;

public interface CRM_userDAO {

	public void insert(CRM_userVO vo) throws Exception;
	
	public CRM_userVO login(LoginDTO dto) throws Exception; 
}
