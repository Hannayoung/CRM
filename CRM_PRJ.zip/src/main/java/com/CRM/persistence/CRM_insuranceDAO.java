package com.CRM.persistence;

import java.util.List;

import com.CRM.domain.CRM_contentVO;
import com.CRM.domain.CRM_insurVO;
import com.CRM.domain.CRM_otherVO;
import com.CRM.domain.CRM_statisticsVO;


public interface CRM_insuranceDAO {	
	
	public CRM_insurVO readInsur_no() throws Exception;
	
	//보험소개
	public CRM_insurVO readInsurCancer_One() throws Exception;
		   
	public CRM_insurVO readInsurTooth_One() throws Exception;
	   
	public List<CRM_contentVO> readInsurCancer_Two() throws Exception;
		   
	public List<CRM_contentVO> readInsurTooth_Two() throws Exception;
	
	//등록
	public void insert(CRM_insurVO vo) throws Exception;
	
	public void coinsert(CRM_contentVO vos) throws Exception;
	
	//수정
	public void insurUpdate(CRM_insurVO insur) throws Exception;
	
	public void insurContUpdate(CRM_contentVO content) throws Exception;
	
	public void coinsertUpdate(CRM_contentVO vos) throws Exception;
	
	//삭제
	public void codelete(Integer content_no) throws Exception;
	  
	//보험비교
	public List<CRM_insurVO> compareInsurC() throws Exception;
	
    public List<CRM_insurVO> compareInsurT() throws Exception;
    
	public List<CRM_contentVO> compareContentC() throws Exception;
	
	public List<CRM_contentVO> compareContentT() throws Exception;
	
	public List<CRM_otherVO> otherInsurC() throws Exception;
	
	public List<CRM_otherVO> otherInsurT() throws Exception;
		
	//판매통계 개수 세기
	public void CountSex(CRM_statisticsVO vo) throws Exception;
	
	public void CountAge(CRM_statisticsVO vo) throws Exception;
	
	public void CountAdr(CRM_statisticsVO vo) throws Exception;
	
	//판매통계 값 가져오기
	public List<CRM_statisticsVO> readSex() throws Exception;
	
	public List<CRM_statisticsVO> readAge() throws Exception;
	
	public List<CRM_statisticsVO> readAdr() throws Exception;
	   
}
	   
