package com.CRM.persistence;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.CRM.domain.CRM_userVO;
import com.CRM.dto.LoginDTO;

@Repository
public class CRM_userDAOImpl implements CRM_userDAO{

	@Inject
	private SqlSession session;
	
	private static String namespace = 
			"com.CRM.mappers.userMapper";
	
	@Override
	public void insert(CRM_userVO vo) throws Exception {
		session.insert(namespace + ".register", vo);
	}

	@Override
	public CRM_userVO login(LoginDTO dto) throws Exception {
		return session.selectOne(namespace + ".login", dto);
	}
	
	
}
