package com.CRM.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.CRM.domain.CRM_contentVO;
import com.CRM.domain.CRM_insurVO;
import com.CRM.domain.CRM_otherVO;
import com.CRM.domain.CRM_statisticsVO;

@Repository
public class CRM_insuranceDAOImpl implements CRM_insuranceDAO {
	
	 @Inject
	  private SqlSession session;
	  private static String namespace = "com.CRM.mappers.InsuranceMapper";

	  @Override
	   public CRM_insurVO readInsur_no() throws Exception {
	      
	      return session.selectOne(namespace + ".readInsur_no");
	   }
	  
	//보험소개	  
	   @Override
	   public CRM_insurVO readInsurCancer_One() throws Exception {
	      
	      return session.selectOne(namespace + ".readInsurCancer_One");
	   }
	   
	   @Override
	   public CRM_insurVO readInsurTooth_One() throws Exception {
	      
	      return session.selectOne(namespace + ".readInsurTooth_One");
	   }
	   
	   @Override
	   public List<CRM_contentVO> readInsurCancer_Two() throws Exception {
	      
	      return session.selectList(namespace + ".readInsurCancer_Two");
	   }
	   
	   @Override
	   public List<CRM_contentVO> readInsurTooth_Two() throws Exception {
	      
	      return session.selectList(namespace + ".readInsurTooth_Two");
	   }
	   
	  //등록
	  @Override
		public void insert(CRM_insurVO vo) throws Exception {
			session.insert(namespace + ".insert", vo);
		}
		
		@Override
		public void coinsert(CRM_contentVO vos) throws Exception {
			session.insert(namespace + ".coinsert", vos);
		}
		
	  //수정
		@Override
		  public void insurUpdate(CRM_insurVO insur) throws Exception {
		    session.update(namespace + ".insurUpdate", insur);
		}
		
		@Override
		  public void insurContUpdate(CRM_contentVO content) throws Exception {
		    session.update(namespace + ".insurContUpdate", content);
		}
		
		@Override
		public void coinsertUpdate(CRM_contentVO vos) throws Exception {
			session.insert(namespace + ".coinsertUpdate", vos);
		}
	
		//삭제
		  @Override
		  public void codelete(Integer content_no) throws Exception {
		    session.delete(namespace + ".codelete", content_no);
		  }
		  
	  //보험비교
	  @Override
	  public List<CRM_insurVO> compareInsurC() throws Exception{
		  return session.selectList(namespace + ".readInsurCancer_One");
	  }
	  
	  @Override
	  public List<CRM_insurVO> compareInsurT() throws Exception{
		  return session.selectList(namespace + ".readInsurTooth_One");
	  }
	  
	  @Override
	  public List<CRM_contentVO> compareContentC() throws Exception{
		  return session.selectList(namespace + ".compareContentC");
	  }
	  
	  @Override
	  public List<CRM_contentVO> compareContentT() throws Exception{
		  return session.selectList(namespace + ".compareContentT");
	  }
	  
	  @Override
	  public List<CRM_otherVO> otherInsurC() throws Exception{
		  return session.selectList(namespace + ".otherInsurC");
	  }
	  
	  @Override
	  public List<CRM_otherVO> otherInsurT() throws Exception{
		  return session.selectList(namespace + ".otherInsurT");
	  }
	
	  
	  //판매통계 개수 세기
	  @Override
	  public void CountSex(CRM_statisticsVO vo) throws Exception {
	    session.update(namespace + ".CountSex", vo);
	  }
	  
	  @Override
	  public void CountAge(CRM_statisticsVO vo) throws Exception {
	    session.update(namespace + ".CountAge", vo);
	  }
	  
	  @Override
	  public void CountAdr(CRM_statisticsVO vo) throws Exception {
	    session.update(namespace + ".CountAdr", vo);
	  }

	  //판매통계 값 가져오기
	  @Override
	  public List<CRM_statisticsVO> readSex() throws Exception {
	    return session.selectList(namespace + ".readSex");
	  }
	  
	  @Override
	  public List<CRM_statisticsVO> readAge() throws Exception {
	    return session.selectList(namespace + ".readAge");
	  }
	  
	  @Override
	  public List<CRM_statisticsVO> readAdr() throws Exception {
	    return session.selectList(namespace + ".readAdr");
	  }
	 
}
