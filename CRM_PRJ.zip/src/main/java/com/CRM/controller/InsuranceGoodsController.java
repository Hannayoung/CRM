package com.CRM.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.CRM.domain.CRM_contentVO;
import com.CRM.domain.CRM_insurVO;
import com.CRM.domain.CRM_statisticsVO;
import com.CRM.service.CRM_insuranceService;

@Controller
@RequestMapping("/insuranceGoods/*")
public class InsuranceGoodsController {
   private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

   @Inject
    private CRM_insuranceService service;
   
   //보험소개
	@RequestMapping(value="/introduceCancer", method=RequestMethod.GET)
	public String introduceCancerGET(Model model) throws Exception {
		logger.info("보험관리 소개 GET ..............");
		model.addAttribute("cancer",service.readInsurCancer_One());
		model.addAttribute("cancercont",service.readInsurCancer_Two());
		return "insuranceGoods/introduceCancer";
	}

	@RequestMapping(value="/introduceTooth", method=RequestMethod.GET)
	public String introduceToothGET(Model model) throws Exception {
		logger.info("보험관리 소개 GET ..............");
		model.addAttribute("tooth",service.readInsurTooth_One());
		model.addAttribute("toothcont",service.readInsurTooth_Two());
		return "insuranceGoods/introduceTooth";
		
	}
	  
	@RequestMapping(value="/introduceCancer/{content_no}", method=RequestMethod.GET)
	public String introduceCancerGET2(Model model,@PathVariable("content_no") Integer content_no, RedirectAttributes rttr) throws Exception {
		logger.info("삭제 GET ..............");
		model.addAttribute("cancer",service.readInsurCancer_One());
		model.addAttribute("cancercont",service.readInsurCancer_Two());
		service.codelete(content_no);
		
		rttr.addFlashAttribute("msg","SUCCESS");
		return "redirect:/insuranceGoods/introduceCancer";
	}
	
	@RequestMapping(value="/introduceTooth/{content_no}", method=RequestMethod.GET)
	public String introduceToothGET2(Model model,@PathVariable("content_no") Integer content_no, RedirectAttributes rttr) throws Exception {
		logger.info("삭제 GET ..............");
		model.addAttribute("cancer",service.readInsurTooth_One());
		model.addAttribute("cancercont",service.readInsurTooth_Two());
		service.codelete(content_no);
		
		rttr.addFlashAttribute("msg","SUCCESS");
		return "redirect:/insuranceGoods/introduceTooth";
	}
	
	//수정
	@RequestMapping(value="/modifyCancer", method=RequestMethod.GET)
	public String modifyCancerGET(Model model) throws Exception {
		logger.info("보험관리 소개 GET ..............");
		model.addAttribute("cancer",service.readInsurCancer_One());
		model.addAttribute("cancercont",service.readInsurCancer_Two());		
		return "insuranceGoods/modifyCancer";		
	}
	
	@RequestMapping(value="/modifyCancer", method=RequestMethod.POST)
	public String modifyCancerPOST(HttpServletRequest request, HttpServletResponse response,
	         CRM_insurVO vo, CRM_contentVO vos, RedirectAttributes rttr,
	         @RequestParam(value = "content_no") Integer [] content_no,
	         @RequestParam(value = "count") int count) throws Exception {
		logger.info("암 보험상품수정 POST ..............");
		logger.info(vo.toString());
		logger.info(vos.toString());
		
		String[] pay_title=request.getParameterValues("pay_title");
	    String[] pay_reason=request.getParameterValues("pay_reason");
	    String[] money=request.getParameterValues("money");
	    
	    service.insurUpdate(vo);
	    
	    //내용 수정
		for(int i = 0; i< money.length-count; i++){
			 vos.setContent_no(content_no[i]);
	         vos.setPay_title(pay_title[i]);
	         vos.setPay_reason(pay_reason[i]);
	         vos.setMoney(money[i]);
	         service.insurContUpdate(vos);
	         }		
	
		//내용 추가 수정
		for(int i = money.length-count; i< money.length; i++){
	         vos.setPay_title(pay_title[i]);
	         vos.setPay_reason(pay_reason[i]);
	         vos.setMoney(money[i]);
	         service.coinsertUpdate(vos);
	         }
			return "redirect:/insuranceGoods/introduceCancer";
	}
	
	@RequestMapping(value="/modifyTooth", method=RequestMethod.GET)
	public String modifyToothGET(Model model) throws Exception {
		logger.info("보험관리 소개 GET ..............");
		model.addAttribute("tooth",service.readInsurTooth_One());
		model.addAttribute("toothcont",service.readInsurTooth_Two());
		return "/insuranceGoods/modifyTooth";		
	}
	
	@RequestMapping(value="/modifyTooth", method=RequestMethod.POST)
	public String modifyToothPOST(HttpServletRequest request, HttpServletResponse response,
	         CRM_insurVO vo, CRM_contentVO vos, RedirectAttributes rttr,
	         @RequestParam(value = "content_no") Integer [] content_no,
	         @RequestParam(value = "count") int count) throws Exception {
		logger.info("암 보험상품수정 POST ..............");
		logger.info(vo.toString());
		logger.info(vos.toString());
		
		String[] pay_title=request.getParameterValues("pay_title");
	    String[] pay_reason=request.getParameterValues("pay_reason");
	    String[] money=request.getParameterValues("money");
	    
	    service.insurUpdate(vo);
	    
	    //내용 수정
		for(int i = 0; i< money.length-count; i++){
			 vos.setContent_no(content_no[i]);
	         vos.setPay_title(pay_title[i]);
	         vos.setPay_reason(pay_reason[i]);
	         vos.setMoney(money[i]);
	         service.insurContUpdate(vos);
	         }		
	
		//내용 추가 수정
		for(int i = money.length-count; i< money.length; i++){
	         vos.setPay_title(pay_title[i]);
	         vos.setPay_reason(pay_reason[i]);
	         vos.setMoney(money[i]);
	         service.coinsertUpdate(vos);
	         }
			return "redirect:/insuranceGoods/introduceTooth";
	}

   @RequestMapping(value="/compareCancer", method=RequestMethod.GET)
   public String compareCancerGET(Model model) throws Exception {
      logger.info("암보험비교 GET ..............");
      model.addAttribute("insurOwn", service.compareInsurC());
      model.addAttribute("content", service.compareContentC());
      model.addAttribute("insurOther", service.otherInsurC());
      return "insuranceGoods/compareCancer";
   }
   
   @RequestMapping(value="/compareTooth", method=RequestMethod.GET)
   public String compareToothGET(Model model) throws Exception {
      logger.info("치아보험비교 GET ..............");
      model.addAttribute("insurOwnT", service.compareInsurT());
      model.addAttribute("contentT", service.compareContentT());
      model.addAttribute("insurOtherT", service.otherInsurT());
      return "insuranceGoods/compareTooth";
   }
   
   @RequestMapping(value = "/statistics", method = RequestMethod.GET)
   public String statisticsGET(CRM_statisticsVO vo, Model model) throws Exception {
	  logger.info("판매통계 GET ..............");
	  service.CountSex(vo);
	  service.CountAge(vo);
	  service.CountAdr(vo);
      model.addAttribute("sex", service.readSex());
      model.addAttribute("age",service.readAge());
      model.addAttribute("adr",service.readAdr());
     return "insuranceGoods/statistics";
   }
   
   @RequestMapping(value="/register", method=RequestMethod.GET)
	public String registerGET(Model model) throws Exception {
		logger.info("보험상품등록 GET ..............");
		model.addAttribute("number",service.readInsur_no());
		return "insuranceGoods/register";
		
	}
   
   @RequestMapping(value="/register", method=RequestMethod.POST)
   public String registerPOST(HttpServletRequest request, HttpServletResponse response,
         CRM_insurVO vo, CRM_contentVO vos, RedirectAttributes rttr) throws Exception {
      logger.info("보험상품등록 POST ..............");
      logger.info(vo.toString());
      logger.info(vos.toString());
      
      String[] pay_title=request.getParameterValues("pay_title");
      String[] pay_reason=request.getParameterValues("pay_reason");
      String[] money=request.getParameterValues("money");
      
      service.insurRegister(vo);
      for(int i = 0; i<money.length; i++){
         vos.setPay_title(pay_title[i]);
         vos.setPay_reason(pay_reason[i]);
         vos.setMoney(money[i]);
         service.insurContRegister(vos);}
      
      return "redirect:/insuranceGoods/register";   
   }
}