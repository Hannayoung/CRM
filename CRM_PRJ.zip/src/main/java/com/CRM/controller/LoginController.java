package com.CRM.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.CRM.domain.CRM_userVO;
import com.CRM.dto.LoginDTO;
import com.CRM.service.CRM_userService;


@Controller
@RequestMapping("/login/*")
public class LoginController {
	@Autowired
	BCryptPasswordEncoder passwordEncoder;
	
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	@Inject
	private CRM_userService service;
	
	@RequestMapping(value="/login/loginForm", method=RequestMethod.GET)
	public void loginGET() throws Exception {
		logger.info("Login GET ..............");
	}
	
	@RequestMapping(value="/login/loginForm", method=RequestMethod.POST)
	public void loginPOST(LoginDTO dto, HttpSession session, Model model) throws Exception {
		
		CRM_userVO vo = service.login(dto);
		System.out.println("dto로 서비스 실행 후 vo : " + vo);
		if(vo == null) {
			return;
		}
		if(dto.getUpw().equals(vo.getUser_pwd())) {
			System.out.println("사용자 입력 패스워드와 계정 패스워드 일치!");
			model.addAttribute("CRM_userVO", vo);
			model.addAttribute("result", "로그인에 성공하였습니다! 환영합니다, " + vo.getUser_name() + "님!");
		}
		else {
			System.out.println("사용자 입력 패스워드 불일치!");
			System.out.println("입력 pwd : " + dto.getUpw());
			System.out.println("계정 pwd : " + vo.getUser_pwd());
			model.addAttribute("result", "입력한 패스워드가 계정 정보와 불일치 합니다.");
		}
		/* 암호화 후, 암호화 적용 미상태...
		if(passwordEncoder.matches(dto.getUpw(), vo.getUser_pwd())) {
			System.out.println("사용자 입력 패스워드와 계정 패스워드 일치!");
			model.addAttribute("MC_userVO", vo);
			model.addAttribute("result", "로그인에 성공하였습니다! 환영합니다, " + vo.getUser_name() + "님!");
		}
		else {
			System.out.println("사용자 입력 패스워드 불일치!");
			model.addAttribute("result", "입력한 패스워드가 계정 정보와 불일치 합니다.");
		}
		*/	
	}
}
