package com.CRM.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.util.WebUtils;

import com.CRM.domain.CRM_userVO;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Model model) {
		logger.info("HomeController > return home; > login form called! .....");
				
		return "home";
	}
	
	@RequestMapping(value="/home", method = RequestMethod.GET)
	public String crmMain(Model model) throws Exception {
		logger.info("/home > main redirect ... ");
		//model.addAttribute("listQuickNotice", notice_service.listQuickNotice());
		//model.addAttribute("listQuick", united_service.listNavigation());
		//logger.info("Main Quick Navigation Board Incoming.............");
		
		
		return "main";
	}
	
	@RequestMapping(value="/logout", method = RequestMethod.GET)
	public String logout(HttpServletRequest request, 
			HttpServletResponse response, HttpSession session) throws Exception {
		Object obj = session.getAttribute("login");
		
		if(obj != null) {
			CRM_userVO vo = (CRM_userVO) obj;
			
			session.removeAttribute("login");
			session.invalidate();
			
			Cookie loginCookie = WebUtils.getCookie(request, "loginCookie");
			
			if (loginCookie != null) {
				loginCookie.setPath("/");
				loginCookie.setMaxAge(0);
				response.addCookie(loginCookie);
			}
		}
		return "/home";
	}
	
	@RequestMapping(value="/Empolyee/emp_main", method=RequestMethod.GET)
	public void empGET() throws Exception {
		logger.info("사원관리 GET ..............");
	}
	
	/*
	@RequestMapping(value="/Goods/good_main", method=RequestMethod.GET)
	public void goodGET() throws Exception {
		logger.info("상품관리 GET ..............");
	}
	*/

	@RequestMapping(value="/Card/card_main", method=RequestMethod.GET)
	public void cardGET() throws Exception {
		logger.info("명함관리 GET ..............");
	}
	
	@RequestMapping(value="/Customer/cus_main", method=RequestMethod.GET)
	public void cusGET() throws Exception {
		logger.info("고객관리 GET ..............");
	}
	
	@RequestMapping(value="/Schedule/sch_main", method=RequestMethod.GET)
	public void schGET() throws Exception {
		logger.info("일정관리 GET ..............");
	}
	
	@RequestMapping(value="/Sales/sales_main", method=RequestMethod.GET)
	public void salesGET() throws Exception {
		logger.info("영업관리 GET ..............");
	}
	
	@RequestMapping(value="/Revenue/rev_main", method=RequestMethod.GET)
	public void revGET() throws Exception {
		logger.info("매출관리 GET ..............");
	}
	
}
