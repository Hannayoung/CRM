package com.CRM.service;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.CRM.domain.CRM_userVO;
import com.CRM.dto.LoginDTO;
import com.CRM.persistence.CRM_userDAO;

@Service
public class CRM_userServiceImpl implements CRM_userService{
	
	@Autowired
	BCryptPasswordEncoder passwordEncoder;
	
	@Inject
	private CRM_userDAO dao;
	
	@Override
	public void register(CRM_userVO vo) throws Exception {
		
		String orgPass = vo.getUser_pwd();
		System.out.println(vo.getUser_id() + "가입 암호 : " + orgPass);
		String encryptPass = passwordEncoder.encode(orgPass);
		System.out.println(vo.getUser_id() + "암호화 : " + encryptPass);
		vo.setUser_pwd(encryptPass);
		
		dao.insert(vo);
	}

	@Override
	public CRM_userVO login(LoginDTO dto) throws Exception {
			
		return dao.login(dto);
	}
	
	
}
