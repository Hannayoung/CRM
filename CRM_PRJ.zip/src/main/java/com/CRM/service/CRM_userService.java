package com.CRM.service;

import com.CRM.domain.CRM_userVO;
import com.CRM.dto.LoginDTO;

public interface CRM_userService {

	public void register(CRM_userVO vo) throws Exception;
	
	public CRM_userVO login(LoginDTO dto) throws Exception;
}
