package com.CRM.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.CRM.domain.CRM_contentVO;
import com.CRM.domain.CRM_insurVO;
import com.CRM.domain.CRM_otherVO;
import com.CRM.domain.CRM_statisticsVO;
import com.CRM.persistence.CRM_insuranceDAO;

@Service
public class CRM_insuranceSerivceImpl implements CRM_insuranceService{
	
	  @Inject
	  private CRM_insuranceDAO dao;
	  
	  @Override
	   public CRM_insurVO readInsur_no() throws Exception{
	      return dao.readInsur_no();
	   }
	  
	  //보험 소개	   
	   @Override
	   public CRM_insurVO readInsurCancer_One() throws Exception {
	      
	      return dao.readInsurCancer_One();
	   }
	   
	   @Override
	   public CRM_insurVO readInsurTooth_One() throws Exception {
	      
	      return dao.readInsurTooth_One();
	   }
	   
	   @Override
	   public List<CRM_contentVO> readInsurCancer_Two() throws Exception {
	      
	      return dao.readInsurCancer_Two();
	   }
	  
	   @Override
	   public List<CRM_contentVO> readInsurTooth_Two() throws Exception {
	      
	      return dao.readInsurTooth_Two();
	   }
	   
	  //등록
		@Override
		public void insurRegister(CRM_insurVO vo) throws Exception {
		
			dao.insert(vo);
		}
		
		@Override
		public void insurContRegister(CRM_contentVO vos) throws Exception{
			dao.coinsert(vos);
		}
	  
	  //수정
		@Transactional
		@Override
		public void insurUpdate(CRM_insurVO insur) throws Exception {
			dao.insurUpdate(insur);
		}
		
		@Transactional
		@Override
		public void insurContUpdate(CRM_contentVO content) throws Exception {
			dao.insurContUpdate(content);
		}
		
		@Override
		public void coinsertUpdate(CRM_contentVO vos) throws Exception{
			dao.coinsertUpdate(vos);
		}
		
	  //삭제
		  @Override
		  public void codelete(Integer content_no) throws Exception {
		    dao.codelete(content_no);
		  } 
	
	  //보험비교
	  @Override
		public List<CRM_insurVO> compareInsurC() throws Exception{
			return dao.compareInsurC();
	  }
		   
	  @Override
	   public List<CRM_insurVO> compareInsurT() throws Exception{
			return dao.compareInsurT();
	  }
	   
	  @Override
	  public List<CRM_contentVO> compareContentC() throws Exception{
		  return dao.compareContentC();
	  }
	  
	  @Override
	  public List<CRM_contentVO> compareContentT() throws Exception{
		  return dao.compareContentT();
	  }
	  
	  @Override
	  public List<CRM_otherVO> otherInsurC() throws Exception{
		  return dao.otherInsurC();
	  }
	  
	  @Override
	  public List<CRM_otherVO> otherInsurT() throws Exception{
		  return dao.otherInsurT();
	  }
	  
	  //판매통계 개수 세기
	  @Override
	  public void CountSex(CRM_statisticsVO vo) throws Exception {
	    dao.CountSex(vo);
	  }
	  
	  @Override
	  public void CountAge(CRM_statisticsVO vo) throws Exception {
	    dao.CountAge(vo);
	  }
	  
	  @Override
	  public void CountAdr(CRM_statisticsVO vo) throws Exception {
	    dao.CountAdr(vo);
	  }
	  
	  //판매통계 값 가져오기
	  @Override
	  public List<CRM_statisticsVO> readSex() throws Exception {
	    return dao.readSex();
	  }
	  
	  @Override
	  public List<CRM_statisticsVO> readAge() throws Exception {
	    return dao.readAge();
	  }
	  
	  @Override
	  public List<CRM_statisticsVO> readAdr() throws Exception {
	    return dao.readAdr();
	  }
	  
}

	
	  
