package com.CRM.domain;

public class CRM_otherVO {
   
    private String oinsur_name;
    private String oinsur_type;
    private String oinsur_term;
    private String opayment_term;
    private String oage;
    private int omoney;
	   
	public String getOinsur_name() {
		return oinsur_name;
	}
	public void setOinsur_name(String oinsur_name) {
		this.oinsur_name = oinsur_name;
	}
	public String getOinsur_type() {
		return oinsur_type;
	}
	public void setOinsur_type(String oinsur_type) {
		this.oinsur_type = oinsur_type;
	}
	public String getOinsur_term() {
		return oinsur_term;
	}
	public void setOinsur_term(String oinsur_term) {
		this.oinsur_term = oinsur_term;
	}
	public String getOpayment_term() {
		return opayment_term;
	}
	public void setOpayment_term(String opayment_term) {
		this.opayment_term = opayment_term;
	}
	public String getOage() {
		return oage;
	}
	public void setOage(String oage) {
		this.oage = oage;
	}
	public int getOmoney() {
		return omoney;
	}
	public void setOmoney(int omoney) {
		this.omoney = omoney;
	}
	
	@Override
	public String toString() {
		return "CRM_otherVO [oinsur_name=" + oinsur_name + ", oinsur_type=" + oinsur_type + ", oinsur_term="
				+ oinsur_term + ", opayment_term=" + opayment_term + ", oage=" + oage + ", omoney=" + omoney + "]";
	}
}