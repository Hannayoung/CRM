package com.CRM.domain;

public class CRM_customerVO {
	private int customer_no;
	private String customer_sex;
	private String customer_age;
	private String customer_adr;
	private String customer_insurance;
	public int getCustomer_no() {
		return customer_no;
	}
	public void setCustomer_no(int customer_no) {
		this.customer_no = customer_no;
	}
	public String getCustomer_sex() {
		return customer_sex;
	}
	public void setCustomer_sex(String customer_sex) {
		this.customer_sex = customer_sex;
	}
	public String getCustomer_age() {
		return customer_age;
	}
	public void setCustomer_age(String customer_age) {
		this.customer_age = customer_age;
	}
	public String getCustomer_adr() {
		return customer_adr;
	}
	public void setCustomer_adr(String customer_adr) {
		this.customer_adr = customer_adr;
	}
	public String getCustomer_insurance() {
		return customer_insurance;
	}
	public void setCustomer_insurance(String customer_insurance) {
		this.customer_insurance = customer_insurance;
	}
	
	@Override
	public String toString() {
		return "CRM_customerVO [customer_no=" + customer_no + ", customer_sex=" + customer_sex + ", customer_age="
				+ customer_age + ", customer_adr=" + customer_adr + ", customer_insurance=" + customer_insurance + "]";
	}
	
	
}
