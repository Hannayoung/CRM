package com.CRM.domain;

public class CRM_insurVO {
	
	private int insur_no;
	private String insur_type;
	private String insur_term;
	private String payment_term;
	private int age;
	private int content_no;
	private String caution;
	public int getInsur_no() {
		return insur_no;
	}
	public void setInsur_no(int insur_no) {
		this.insur_no = insur_no;
	}
	public String getInsur_type() {
		return insur_type;
	}
	public void setInsur_type(String insur_type) {
		this.insur_type = insur_type;
	}
	public String getInsur_term() {
		return insur_term;
	}
	public void setInsur_term(String insur_term) {
		this.insur_term = insur_term;
	}
	public String getPayment_term() {
		return payment_term;
	}
	public void setPayment_term(String payment_term) {
		this.payment_term = payment_term;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getContent_no() {
		return content_no;
	}
	public void setContent_no(int content_no) {
		this.content_no = content_no;
	}
	public String getCaution() {
		return caution;
	}
	public void setCaution(String caution) {
		this.caution = caution;
	}
	@Override
	public String toString() {
		return "CRM_insurVO [insur_no=" + insur_no + ", insur_type=" + insur_type + ", insur_term=" + insur_term
				+ ", payment_term=" + payment_term + ", age=" + age + ", content_no=" + content_no + ", caution="
				+ caution + ", getInsur_no()=" + getInsur_no() + ", getInsur_type()=" + getInsur_type()
				+ ", getInsur_term()=" + getInsur_term() + ", getPayment_term()=" + getPayment_term() + ", getAge()="
				+ getAge() + ", getContent_no()=" + getContent_no() + ", getCaution()=" + getCaution() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
