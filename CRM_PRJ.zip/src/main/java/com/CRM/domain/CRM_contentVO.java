package com.CRM.domain;

public class CRM_contentVO{

	private int content_no;
	private int insur_no;
	private String pay_title;
	private String pay_reason;
	private String money;
	private int count;
	
	public int getContent_no() {
		return content_no;
	}
	public void setContent_no(int content_no) {
		this.content_no = content_no;
	}
	public int getInsur_no() {
		return insur_no;
	}
	public void setInsur_no(int insur_no) {
		this.insur_no = insur_no;
	}
	public String getPay_title() {
		return pay_title;
	}
	public void setPay_title(String pay_title) {
		this.pay_title = pay_title;
	}
	public String getPay_reason() {
		return pay_reason;
	}
	public void setPay_reason(String pay_reason) {
		this.pay_reason = pay_reason;
	}
	public String getMoney() {
		return money;
	}
	public void setMoney(String money) {
		this.money = money;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return "CRM_contentVO [content_no=" + content_no + ", insur_no=" + insur_no + ", pay_title=" + pay_title
				+ ", pay_reason=" + pay_reason + ", money=" + money + ", count=" + count + "]";
	}
	
	
}
