package com.CRM.domain;

public class CRM_statisticsVO {
	private int no;
	private int c_man;
	private int c_woman;
	
	private int c_ten;
	private int c_twenty;
	private int c_thirty;
	private int c_forty;
	private int c_fifty;
	private int c_sixty;
	private int c_seventy;
	private int c_eighty;
	
	private int c_seoul;
	private int c_gyounggi;
	private int c_gangwon;
	private int c_chungchung;
	private int c_junra;
	private int c_gyoungsang;
	private int c_jeju;
	
	private int t_man;
	private int t_woman;
	
	private int t_ten;
	private int t_twenty;
	private int t_thirty;
	private int t_forty;
	private int t_fifty;
	private int t_sixty;
	private int t_seventy;
	private int t_eighty;
	
	private int t_seoul;
	private int t_gyounggi;
	private int t_gangwon;
	private int t_chungchung;
	private int t_junra;
	private int t_gyoungsang;
	private int t_jeju;
	
	public int getNo() {
		return no;
	}
	
	public void setNo(int no) {
		this.no = no;
	}
	
	public int getC_man() {
		return c_man;
	}
	public void setC_man(int c_man) {
		this.c_man = c_man;
	}
	public int getC_woman() {
		return c_woman;
	}
	public void setC_woman(int c_woman) {
		this.c_woman = c_woman;
	}
	public int getC_ten() {
		return c_ten;
	}
	public void setC_ten(int c_ten) {
		this.c_ten = c_ten;
	}
	public int getC_twenty() {
		return c_twenty;
	}
	public void setC_twenty(int c_twenty) {
		this.c_twenty = c_twenty;
	}
	public int getC_thirty() {
		return c_thirty;
	}
	public void setC_thirty(int c_thirty) {
		this.c_thirty = c_thirty;
	}
	public int getC_forty() {
		return c_forty;
	}
	public void setC_forty(int c_forty) {
		this.c_forty = c_forty;
	}
	public int getC_fifty() {
		return c_fifty;
	}
	public void setC_fifty(int c_fifty) {
		this.c_fifty = c_fifty;
	}
	public int getC_sixty() {
		return c_sixty;
	}
	public void setC_sixty(int c_sixty) {
		this.c_sixty = c_sixty;
	}
	public int getC_seventy() {
		return c_seventy;
	}
	public void setC_seventy(int c_seventy) {
		this.c_seventy = c_seventy;
	}
	public int getC_eighty() {
		return c_eighty;
	}
	public void setC_eighty(int c_eighty) {
		this.c_eighty = c_eighty;
	}
	public int getC_seoul() {
		return c_seoul;
	}
	public void setC_seoul(int c_seoul) {
		this.c_seoul = c_seoul;
	}
	public int getC_gyounggi() {
		return c_gyounggi;
	}
	public void setC_gyounggi(int c_gyounggi) {
		this.c_gyounggi = c_gyounggi;
	}
	public int getC_gangwon() {
		return c_gangwon;
	}
	public void setC_gangwon(int c_gangwon) {
		this.c_gangwon = c_gangwon;
	}
	public int getC_chungchung() {
		return c_chungchung;
	}
	public void setC_chungchung(int c_chungchung) {
		this.c_chungchung = c_chungchung;
	}
	public int getC_junra() {
		return c_junra;
	}
	public void setC_junra(int c_junra) {
		this.c_junra = c_junra;
	}
	public int getC_gyoungsang() {
		return c_gyoungsang;
	}
	public void setC_gyoungsang(int c_gyoungsang) {
		this.c_gyoungsang = c_gyoungsang;
	}
	public int getC_jeju() {
		return c_jeju;
	}
	public void setC_jeju(int c_jeju) {
		this.c_jeju = c_jeju;
	}
	public int getT_man() {
		return t_man;
	}
	public void setT_man(int t_man) {
		this.t_man = t_man;
	}
	public int getT_woman() {
		return t_woman;
	}
	public void setT_woman(int t_woman) {
		this.t_woman = t_woman;
	}
	public int getT_ten() {
		return t_ten;
	}
	public void setT_ten(int t_ten) {
		this.t_ten = t_ten;
	}
	public int getT_twenty() {
		return t_twenty;
	}
	public void setT_twenty(int t_twenty) {
		this.t_twenty = t_twenty;
	}
	public int getT_thirty() {
		return t_thirty;
	}
	public void setT_thirty(int t_thirty) {
		this.t_thirty = t_thirty;
	}
	public int getT_forty() {
		return t_forty;
	}
	public void setT_forty(int t_forty) {
		this.t_forty = t_forty;
	}
	public int getT_fifty() {
		return t_fifty;
	}
	public void setT_fifty(int t_fifty) {
		this.t_fifty = t_fifty;
	}
	public int getT_sixty() {
		return t_sixty;
	}
	public void setT_sixty(int t_sixty) {
		this.t_sixty = t_sixty;
	}
	public int getT_seventy() {
		return t_seventy;
	}
	public void setT_seventy(int t_seventy) {
		this.t_seventy = t_seventy;
	}
	public int getT_eighty() {
		return t_eighty;
	}
	public void setT_eighty(int t_eighty) {
		this.t_eighty = t_eighty;
	}
	public int getT_seoul() {
		return t_seoul;
	}
	public void setT_seoul(int t_seoul) {
		this.t_seoul = t_seoul;
	}
	public int getT_gyounggi() {
		return t_gyounggi;
	}
	public void setT_gyounggi(int t_gyounggi) {
		this.t_gyounggi = t_gyounggi;
	}
	public int getT_gangwon() {
		return t_gangwon;
	}
	public void setT_gangwon(int t_gangwon) {
		this.t_gangwon = t_gangwon;
	}
	public int getT_chungchung() {
		return t_chungchung;
	}
	public void setT_chungchung(int t_chungchung) {
		this.t_chungchung = t_chungchung;
	}
	public int getT_junra() {
		return t_junra;
	}
	public void setT_junra(int t_junra) {
		this.t_junra = t_junra;
	}
	public int getT_gyoungsang() {
		return t_gyoungsang;
	}
	public void setT_gyoungsang(int t_gyoungsang) {
		this.t_gyoungsang = t_gyoungsang;
	}
	public int getT_jeju() {
		return t_jeju;
	}
	public void setT_jeju(int t_jeju) {
		this.t_jeju = t_jeju;
	}
	
	@Override
	public String toString() {
		return "CRM_statisticsVO [c_man=" + c_man + ", c_woman=" + c_woman + ", c_ten=" + c_ten + ", c_twenty="
				+ c_twenty + ", c_thirty=" + c_thirty + ", c_forty=" + c_forty + ", c_fifty=" + c_fifty + ", c_sixty="
				+ c_sixty + ", c_seventy=" + c_seventy + ", c_eighty=" + c_eighty + ", c_seoul=" + c_seoul
				+ ", c_gyounggi=" + c_gyounggi + ", c_gangwon=" + c_gangwon + ", c_chungchung=" + c_chungchung
				+ ", c_junra=" + c_junra + ", c_gyoungsang=" + c_gyoungsang + ", c_jeju=" + c_jeju + ", t_man=" + t_man
				+ ", t_woman=" + t_woman + ", t_ten=" + t_ten + ", t_twenty=" + t_twenty + ", t_thirty=" + t_thirty
				+ ", t_forty=" + t_forty + ", t_fifty=" + t_fifty + ", t_sixty=" + t_sixty + ", t_seventy=" + t_seventy
				+ ", t_eighty=" + t_eighty + ", t_seoul=" + t_seoul + ", t_gyounggi=" + t_gyounggi + ", t_gangwon="
				+ t_gangwon + ", t_chungchung=" + t_chungchung + ", t_junra=" + t_junra + ", t_gyoungsang="
				+ t_gyoungsang + ", t_jeju=" + t_jeju + "]";
	}
	
	
}
